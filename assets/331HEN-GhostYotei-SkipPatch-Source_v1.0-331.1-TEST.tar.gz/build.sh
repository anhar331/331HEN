#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 - <<'PY'
from pathlib import Path
b=Path('PPSA26344_01.008.000-AllowSkip-TEST.xml').read_bytes()
Path('patch_xml.h').write_text('static const unsigned char patch_xml[]={'+','.join(str(x) for x in b)+',0};\n')
PY
mkdir -p Release
docker --host=unix:///var/run/docker.sock run --rm --user "$(id -u):$(id -g)" \
 --mount "type=bind,src=$PWD,dst=/src" -w /src 331hen-builder \
 /opt/ps5-payload-sdk/bin/prospero-clang -Os -Wall -Wextra -Wno-misleading-indentation -Werror installer.c \
 -o Release/331HEN-GhostYotei-SkipPatch-Installer_v1.0-331.1-TEST.elf
