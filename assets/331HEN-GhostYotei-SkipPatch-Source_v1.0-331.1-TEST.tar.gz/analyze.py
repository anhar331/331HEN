from pathlib import Path
import sys,struct,re,json
sys.path.insert(0,str(Path(__file__).parent/'python-deps'))
from capstone import Cs,CS_ARCH_X86,CS_MODE_64
b=Path(__file__).with_name('eboot.bin').read_bytes()
ph=[struct.unpack_from('<IIQQQQQQ',b,64+i*56) for i in range(14)]
def vaoff(v):
 for t,f,o,a,pa,sz,ms,al in ph:
  if t==1 and a<=v<a+sz:return o+v-a
 raise ValueError(hex(v))
def offva(o):
 for t,f,po,a,pa,sz,ms,al in ph:
  if t==1 and po<=o<po+sz:return a+o-po
 raise ValueError(hex(o))
cs=Cs(CS_ARCH_X86,CS_MODE_64)
targets={}
for key in [b'AllowSkippingCutscenes',b'DisableSkipMovie',b'SkipCutscene',b'virtual bool CPolycutManifest::FTrySkipCutscene()',b'virtual bool CMovie::FTrySkipCutscene()',b'kParam_TimeScale',b'CloudTimeScale']:
 off=b.find(key+b'\0')
 if off>=0:targets[offva(off)]=key.decode()
print('TARGETS',json.dumps({hex(k):v for k,v in targets.items()}))
refs=[]
for m in re.finditer(rb'[\x48-\x4f]\x8d[\x05\x0d\x15\x1d\x25\x2d\x35\x3d][\x00-\xff]{4}',b[0x4000:0x4000+0x16cdc4c]):
 o=m.start()+0x4000;a=offva(o);dest=a+7+struct.unpack_from('<i',b,o+3)[0]
 if dest in targets:
  refs.append({'address':hex(a),'target':targets[dest]})
  print('\nREFERENCE',hex(a),targets[dest])
  # Context from a nearby known alignment, candidate decode only.
  start=o-64
  for ins in cs.disasm(b[start:o+95],offva(start)):
   print(hex(ins.address),ins.mnemonic,ins.op_str)
Path(__file__).with_name('string-refs.json').write_text(json.dumps(refs,indent=2))
