/* GPL-3.0-or-later. Installs one experimental XML; never touches game RAM/save/kernel. */
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "patch_xml.h"
#define NAME "PPSA26344_01.008.000-AllowSkip-TEST.xml"
#ifndef HOST_TEST
typedef struct { char prefix[45]; char message[3075]; } notify_request_t;
extern int sceKernelSendNotificationRequest(int,notify_request_t *,size_t,int);
#endif
static void notify(const char *message) {
 puts(message);
#ifndef HOST_TEST
 notify_request_t n={0};snprintf(n.message,sizeof(n.message),"%s",message);sceKernelSendNotificationRequest(0,&n,sizeof(n),0);
#endif
}
static int child(int parent,const char *name) {
 if(mkdirat(parent,name,0755)<0 && errno!=EEXIST)return -1;
 return openat(parent,name,O_RDONLY|O_DIRECTORY|O_NOFOLLOW);
}
static int same_file(int dir) {
 int fd=openat(dir,NAME,O_RDONLY|O_NOFOLLOW);if(fd<0)return 0;
 struct stat s;int same=fstat(fd,&s)==0&&S_ISREG(s.st_mode)&&(size_t)s.st_size==sizeof(patch_xml)-1;
 unsigned char data[sizeof(patch_xml)];size_t pos=0;
 while(same&&pos<sizeof(patch_xml)-1){ssize_t n=read(fd,data+pos,sizeof(patch_xml)-1-pos);if(n<=0){same=0;break;}pos+=(size_t)n;}
 if(same)same=memcmp(data,patch_xml,sizeof(patch_xml)-1)==0;
 close(fd);return same;
}
static int install(const char *base) {
 int basefd=-1,hen=-1,root=-1,xml=-1,config=-1,dir=-1,cur=-1,tmpfd=-1;int result=-1;
 char temp[96]={0};char active[69]={0};
 basefd=open(base,O_RDONLY|O_DIRECTORY|O_NOFOLLOW);if(basefd<0)goto done;
 hen=child(basefd,"331HEN");if(hen<0)goto done;
 root=child(hen,"patches");if(root<0)goto done;
 xml=child(root,"xml");config=child(root,"config");if(xml<0||config<0)goto done;
 cur=openat(config,"current",O_RDONLY|O_NOFOLLOW);
 if(cur>=0){
  struct stat s;if(fstat(cur,&s)||!S_ISREG(s.st_mode)||s.st_size<64||s.st_size>66){errno=EINVAL;goto done;}
  size_t got=0;while(got<(size_t)s.st_size){ssize_t n=read(cur,active+got,(size_t)s.st_size-got);if(n<=0)goto done;got+=(size_t)n;}
  while(got&&(active[got-1]=='\n'||active[got-1]=='\r'))active[--got]=0;
  if(got!=64||strspn(active,"0123456789abcdef")!=64){errno=EINVAL;goto done;}
  dir=child(xml,active);if(dir<0)goto done;
 }else if(errno==ENOENT){dir=dup(xml);if(dir<0)goto done;}else goto done;
 if(same_file(dir)){result=1;goto done;}
 struct stat existing;if(fstatat(dir,NAME,&existing,AT_SYMLINK_NOFOLLOW)==0){errno=EEXIST;goto done;}if(errno!=ENOENT)goto done;
 snprintf(temp,sizeof(temp),".331hen-skip-%ld.tmp",(long)getpid());
 tmpfd=openat(dir,temp,O_WRONLY|O_CREAT|O_EXCL|O_NOFOLLOW,0644);if(tmpfd<0)goto done;
 size_t pos=0;while(pos<sizeof(patch_xml)-1){ssize_t n=write(tmpfd,patch_xml+pos,sizeof(patch_xml)-1-pos);if(n<0&&errno==EINTR)continue;if(n<=0)goto done;pos+=(size_t)n;}
 if(fsync(tmpfd)<0)goto done;
 if(close(tmpfd)<0){tmpfd=-1;goto done;}tmpfd=-1;
 /* Atomic publish without replacing any existing definition. */
 if(linkat(dir,temp,dir,NAME,0)<0)goto done;
 unlinkat(dir,temp,0);temp[0]=0;fsync(dir);result=0;
done:
 {int saved=errno;if(tmpfd>=0)close(tmpfd);if(dir>=0&&temp[0])unlinkat(dir,temp,0);
 if(cur>=0)close(cur);if(dir>=0)close(dir);if(config>=0)close(config);if(xml>=0)close(xml);if(root>=0)close(root);if(hen>=0)close(hen);if(basefd>=0)close(basefd);errno=saved;}
 return result;
}
int main(int argc,char **argv) {
#ifndef HOST_TEST
 (void)argc;(void)argv;const char *base="/data";
#else
 if(argc!=2)return 2;const char *base=argv[1];
#endif
 int r=install(base);
 if(r<0){char message[256];snprintf(message,sizeof(message),"331HEN skip TEST install failed: %s. No existing files replaced.",strerror(errno));notify(message);return 1;}
 notify(r==1?"331HEN skip TEST definition already installed. No memory patch applied.":"331HEN skip TEST XML installed. Reboot/reactivate HEN, choose Ghost of Yotei in Game Patches and enable it before launch. NOT PS5-tested.");
 return 0;
}
