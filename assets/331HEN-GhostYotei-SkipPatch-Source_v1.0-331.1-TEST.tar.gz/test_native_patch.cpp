#include "patches/core.hpp"
#include <fstream>
#include <sstream>
#include <cassert>
#include <cstring>
#include <iostream>
using namespace hen331::patches;
struct RAM:Memory {
 std::vector<unsigned char> bytes;Target target;int writes=0;bool stopped=false;
 bool same(const Target &t)override{return t.pid==target.pid&&t.generation==target.generation;}
 bool freeze(const Target&)override{stopped=true;return true;}
 bool resume(const Target&)override{stopped=false;return true;}
 bool read(uint64_t a,void*p,size_t n)override{if(a<target.base||a-target.base+n>bytes.size())return false;memcpy(p,bytes.data()+a-target.base,n);return true;}
 bool write(uint64_t a,const void*p,size_t n)override{assert(stopped);if(a<target.base||a-target.base+n>bytes.size())return false;memcpy(bytes.data()+a-target.base,p,n);writes++;return true;}
};
std::string text(const char*p){std::ifstream f(p,std::ios::binary);std::ostringstream o;o<<f.rdbuf();return o.str();}
int main(int argc,char**argv){assert(argc==3);auto xml=text(argv[1]);std::string error;std::vector<Patch>ps;assert(parse(xml,ps,error));assert(ps.size()==1);auto&p=ps[0];assert(p.unsupported.empty());assert(p.imagebase==0);assert(p.lines.size()==8);assert(matches(p,"PPSA26344","01.008.000"));assert(!matches(p,"PPSA26344","01.009.000"));assert(!matches(p,"PPSA26343","01.008.000"));
 auto elf=text(argv[2]);RAM m;assert(elf.size()>0x16d1c4c);m.bytes.assign(elf.begin()+0x4000,elf.begin()+0x4000+0x16cdc4c);auto original=m.bytes;
 m.target={1,2,3,0x100000000ULL,"PPSA26344","01.008.000","eboot.bin",{{0x100000000ULL,m.bytes.size()}}};Engine e;e.reset(m.target);std::string status;assert(e.toggle(p,m.target,m,true,status));assert(e.applied(p.key));assert(m.writes==8);assert(!m.stopped);
 for(auto&line:p.lines)assert(memcmp(m.bytes.data()+line.address,line.bytes.data(),line.bytes.size())==0);
 assert(e.toggle(p,m.target,m,true,status));assert(m.writes==8);
 assert(e.toggle(p,m.target,m,false,status));assert(!e.applied(p.key));assert(m.bytes==original);assert(m.writes==16);assert(!m.stopped);
 auto wrong=m.target;wrong.version="01.009.000";assert(!e.toggle(p,wrong,m,true,status));assert(m.bytes==original);
 std::cout<<"PASS: actual 331HEN parser/engine; strict title/version, 8 supported lines, rebasing, apply/readback, duplicate protection, exact restoration and mismatched-session refusal.\n";
}
