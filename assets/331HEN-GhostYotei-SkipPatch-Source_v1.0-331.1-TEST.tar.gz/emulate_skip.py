exec(open('analyze.py').read().split("print('TARGETS'")[0])
from unicorn import Uc,UC_ARCH_X86,UC_MODE_64
from unicorn.x86_const import *
from itertools import product
sites=json.loads(Path('PATCH-SITES.json').read_text())['sites']
funcs=[(0xe1e800,0xe1e8d0,0,3),(0xe1e8d0,0xe1e9a0,0x108,3),(0x10e3630,0x10e3730,0,6),(0x10e3730,0x10e3810,0x130,6),(0x11f4380,0x11f4410,0,None)]
actor,component,handles,obj,manifest,stack,stop=range(0x8000000,0x8700000,0x100000)
globalactor=0x51e1978;globalhandles=0x6b642f0

def run(fn,patched,permission,kind,hasactor,has_handle,state,mode,authored):
 start,end,adjust,active=fn;uc=Uc(UC_ARCH_X86,UC_MODE_64);mapped=set()
 def mapat(addr,size=0x1000):
  for page in range(addr&~0xfff,(addr+size+0xfff)&~0xfff,0x1000):
   if page not in mapped:uc.mem_map(page,0x1000);mapped.add(page)
 for addr,size in [(actor,0x5000),(component,0x1000),(handles,0x1000),(obj,0x1000),(manifest,0x1000),(stack,0x1000),(stop,0x1000),(start,end-start)]:mapat(addr,size)
 code=bytearray(b[vaoff(start):vaoff(end)])
 for ins in cs.disasm(code,start):
  m=re.search(r'\[rip (\+|-) (0x[0-9a-f]+)\]',ins.op_str)
  if m:
   dest=ins.address+ins.size+int(m[2],16)*(1 if m[1]=='+' else -1);mapat(dest,8)
 for a in [globalactor,globalhandles]:mapat(a,8)
 if patched:
  for x in sites:
   a=int(x['address'],16)
   if start<=a<end:code[a-start:a-start+len(bytes.fromhex(x['patched']))]=bytes.fromhex(x['patched'])
 uc.mem_write(start,bytes(code))
 def w(a,val,fmt):uc.mem_write(a,struct.pack(fmt,val))
 w(globalactor,actor if hasactor else 0,'<Q');w(globalhandles,handles,'<Q');w(handles+16,1 if has_handle else 0,'<Q')
 w(obj+0xd0,1 if has_handle else -1,'<h')
 w(actor+0xd4,255 if kind=='cached' else 0,'<B');w(actor+0xc0,0 if kind=='missing_component' else component,'<Q');w(actor+0x3147,permission,'<B')
 w(component+4,1 if kind in ['packed','missing_capability'] else 0,'<B')
 w(component+0x18,0 if kind=='missing_capability' else 0x2000,'<Q');w(component+0x52,0,'<H');w(component+0x3c,128 if permission else 0,'<B')
 w(obj+0x110,state,'<I');w(obj+0x138,state,'<I');w(obj+0x148,manifest,'<Q');w(obj+0x17c,mode,'<i');w(manifest+0x44,authored,'<I')
 sp=stack+0x800;w(sp,stop,'<Q');uc.reg_write(UC_X86_REG_RSP,sp);uc.reg_write(UC_X86_REG_RDI,obj+adjust)
 uc.emu_start(start,stop,count=1000)
 assert uc.reg_read(UC_X86_REG_RIP)==stop,hex(uc.reg_read(UC_X86_REG_RIP))
 return uc.reg_read(UC_X86_REG_RAX)&0xff
checks=0;changed=0
for fn in funcs:
 for kind,hasactor,handle in product(['cached','typed_cache','packed','missing_component','missing_capability'],[False,True],[False,True]):
  scenarios=[(fn[3] or 0,1,0),(0,1,0),(fn[3] or 0,0,0),(fn[3] or 0,-1,4),(fn[3] or 0,-1,0)] if fn[3] else [(0,1,0)]
  for state,mode,authored in scenarios:
   args=(kind,hasactor,handle,state,mode,authored)
   expected=run(fn,False,1,*args);actual=run(fn,True,0,*args)
   assert actual==expected,(hex(fn[0]),args,expected,actual)
   baseline=run(fn,False,0,*args)
   changed+=actual!=baseline;checks+=1
print(f'PASS: {checks} real x86-64 emulation cases; {changed} eligibility cases unlocked; invalid actor/handle/component, wrong state and authored restrictions preserved.')
Path('EMULATION-RESULTS.json').write_text(json.dumps({'cases':checks,'eligibility_changed_cases':changed,'passed':True,'oracle':'original code with permission=true versus patched code with permission=false','ps5_runtime_tested':False},indent=2))
