from pathlib import Path
import tempfile,subprocess
b=Path('PPSA26344_01.008.000-AllowSkip-TEST.xml').read_bytes();count=0
with tempfile.TemporaryDirectory() as t:
 p=Path(t);base=p/'data';base.mkdir()
 def run(ok):
  global count
  r=subprocess.run(['./installer-host',str(base)],capture_output=True,text=True)
  assert (r.returncode==0)==ok,(r.returncode,r.stdout,r.stderr);count+=1
 run(True);target=base/'331HEN/patches/xml'/Path('PPSA26344_01.008.000-AllowSkip-TEST.xml');assert target.read_bytes()==b;run(True)
 config=base/'331HEN/patches/config/current';config.write_text('a'*64+'\n');run(True)
 active=base/'331HEN/patches/xml'/('a'*64)/target.name;assert active.read_bytes()==b
 active.write_text('existing patch');run(False);assert active.read_text()=='existing patch'
 config.write_text('../../bad');run(False);assert config.read_text()=='../../bad'
 config.unlink();config.symlink_to(p/'foreign');run(False);assert not (p/'foreign').exists();config.unlink()
 target.unlink();target.symlink_to(p/'foreign');run(False);assert not (p/'foreign').exists();target.unlink()
 xml=base/'331HEN/patches/xml';backup=base/'saved-xml';xml.rename(backup);xml.symlink_to(p/'outside',target_is_directory=True);run(False)
 assert not (p/'outside').exists()
 assert not list(backup.rglob('.331hen-skip-*.tmp'))
print('PASS',count,'installer scenarios: initial/repeat/active-collection, foreign-file and unsafe-path refusals; existing files preserved.')
