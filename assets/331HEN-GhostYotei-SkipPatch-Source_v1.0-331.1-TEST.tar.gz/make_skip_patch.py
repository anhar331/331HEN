from pathlib import Path
import hashlib,json,xml.etree.ElementTree as E,struct
p=Path(__file__).parent;b=(p/'eboot.bin').read_bytes()
expected_sha='db0a7b9d28611bcb918554166d873fdc560b82f6582be70e731a80bbb3d4037e'
assert hashlib.sha256(b).hexdigest()==expected_sha
sites=[(0xe1e880,'743f','9090'),(0xe1e8bf,'75c1','ebc1'),(0xe1e950,'743c','9090'),(0xe1e98c,'75c4','ebc4'),(0x10e36c5,'74ab','9090'),(0x10e37b5,'74b5','9090'),(0x11f43c9,'0fb68147310000','b8010000009090'),(0x11f4403,'c0e807','b00190')]
for a,old,new in sites:
 assert len(old)==len(new)
 assert b[a+0x4000:a+0x4000+len(bytes.fromhex(old))].hex()==old
root=E.Element('Patch');ids=E.SubElement(root,'TitleID');E.SubElement(ids,'ID').text='PPSA26344'
m=E.SubElement(root,'Metadata',{'Title':'Ghost of Yotei','Name':'Enable existing cutscene skip permission (EXPERIMENTAL)','Author':'331HEN research','AppVer':'01.008.000','AppElf':'eboot.bin','ImageBase':'0x0','PatchVer':'1.0-test','Note':'EXPERIMENTAL / NOT PS5-tested. Enables existing skip permission checks; preserves cinematic-state, handle and authored scene checks. Use the normal in-game skip control. No speed boost or custom hotkeys. Restart game required. Exact analyzed eboot SHA256 '+expected_sha+'. Some scenes remain intentionally unskippable.'})
lines=E.SubElement(m,'PatchList')
for a,old,new in sites:E.SubElement(lines,'Line',{'Type':'bytes','Address':hex(a),'Value':new})
E.indent(root);(p/'PPSA26344_01.008.000-AllowSkip-TEST.xml').write_bytes(E.tostring(root,encoding='utf-8',xml_declaration=True))
(p/'PATCH-SITES.json').write_text(json.dumps({'input_sha256':expected_sha,'imagebase':0,'sites':[{'address':hex(a),'original':o,'patched':n} for a,o,n in sites],'ps5_runtime_tested':False},indent=2))
print('Verified',len(sites),'original sequences;',sum(len(bytes.fromhex(x[1])) for x in sites),'replacement bytes')
