#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
export BUILD_VERSION=0.6.1-331.1 CUSTOM_VERSION=331.1
docker --host=unix:///var/run/docker.sock run --rm --user "$(id -u):$(id -g)" \
  --mount "type=bind,src=$PWD,dst=/src" \
  --mount type=bind,src=/etc/ssl/certs/ca-certificates.crt,dst=/run/ca.pem,readonly \
  -e SSL_CERT_FILE=/run/ca.pem -e BUILD_VERSION -e CUSTOM_VERSION -w /src 331hen-builder \
  make all 'LIBS=/opt/ps5-payload-sdk/target/user/homebrew/lib/libmicrohttpd.a -L/opt/ps5-payload-sdk/target/lib -lpthread -lSceNetCtl -lSceUserService -lSceSystemService -lSceAppInstUtil' \
  'CFLAGS=-Os -Wall -ffunction-sections -fdata-sections -Iinclude -Ithird_party/ps5-webkit-remote-loader/installer/common -I/opt/ps5-payload-sdk/target/include -I/opt/ps5-payload-sdk/target/user/homebrew/include'
